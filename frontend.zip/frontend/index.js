

var drawing = false;

var prevX, prevY;

document.onreadystatechange = function () 
{
	var canvas = document.getElementById("canvas");
	var clearButton = document.getElementById("clear_button");

	//It is necessary to set the height and width of the canvas element to the 
	//actual values that are rendered, because the coordinate system does not 
	//match them by default and instead stays at a default 300x150 pixels.
	canvas_style = getComputedStyle(canvas);
	canvas.setAttribute('width', parseInt(canvas_style.width));
	canvas.setAttribute('height', parseInt(canvas_style.height));

	const ctx = canvas.getContext('2d');
	
	canvas.onmousemove = function(event)
	{	
		if(drawing)
		{
			draw_point(event.offsetX, event.offsetY, 4, ctx);
		}
	}

	canvas.onmousedown = function(event)
	{
		drawing = true;
		prevX=event.offsetX;
		prevY=event.offsetY;
		draw_point(event.offsetX, event.offsetY, 4, ctx);
	}

	canvas.onmouseup = function(event)
	{
		drawing = false;
	}

	canvas.onmouseout = function(event)
	{
		drawing = false;
	}

	clear_button.onclick = function(event)
	{
		ctx.clearRect(0, 0, canvas.width, canvas.height);
	}

};

window.onresize = function(event)
{
	var canvas = document.getElementById("canvas");
	canvas_style = getComputedStyle(canvas);
	canvas.setAttribute('width', parseInt(canvas_style.width));
	canvas.setAttribute('height', parseInt(canvas_style.height));
}


function draw_point(x,y,size,ctx)
{
	ctx.beginPath();
    ctx.moveTo(prevX, prevY);
    ctx.lineTo(x, y);
    ctx.strokeStyle = "white";
    ctx.lineWidth = size;
    ctx.stroke();
    ctx.closePath();

    prevX=x;
    prevY=y;

	/*
	ctx.fillStyle="white";
	ctx.beginPath();
	ctx.ellipse(x, y, size, size, 0, 0, 2*Math.PI, false);
	ctx.fill();
	*/
}